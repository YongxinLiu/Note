#' @export
ggplot2::ggplot_add

#' @export
ggplot2::aes

#' @export
magrittr::`%>%`

#' @export
dplyr::filter

#' @export
dplyr::mutate

#' @export
tidygraph::as_tbl_graph

#' @export
igraph::as.igraph
