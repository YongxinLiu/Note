"meanvar" <-
function(tree,...) UseMethod('meanvar')

