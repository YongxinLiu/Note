library(testthat)
library(animalcules)

test_check("animalcules")
